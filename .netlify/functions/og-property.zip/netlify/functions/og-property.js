var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/og-property.ts
var og_property_exports = {};
__export(og_property_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(og_property_exports);
var handler = async (event) => {
  const path = event.path;
  const [, , slug, id] = path.split("/");
  const property = {
    title: "Apartamento Frente Mar em Balne\xE1rio Cambori\xFA",
    description: "Im\xF3vel de alto padr\xE3o em Balne\xE1rio Cambori\xFA. Confira fotos, valores e detalhes.",
    image: "https://picsum.photos/1200/630.jpg",
    url: `https://helenoalvesbc.com.br${path}`
  };
  const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8" />
<title>${property.title}</title>

<meta property="og:type" content="website" />
<meta property="og:title" content="${property.title}" />
<meta property="og:description" content="${property.description}" />
<meta property="og:image" content="${property.image}" />
<meta property="og:url" content="${property.url}" />

<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />

<meta http-equiv="refresh" content="0;url=${property.url}" />
</head>
<body></body>
</html>`;
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "text/html"
    },
    body: html
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
